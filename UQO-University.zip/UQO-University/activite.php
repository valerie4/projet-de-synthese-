<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>UQO-University</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME CSS -->
<link rel="shortcut icon" href="assets\images\UQO-Univ.png" type="image/vnd.microsoft.icon" />
<link href="assets/css/font-awesome.min.css" rel="stylesheet" />
     <!-- FLEXSLIDER CSS -->
<link href="assets/css/flexslider.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />    
  <!-- Google	Fonts -->
  <link href="assets/css/styles.css" rel="stylesheet" />    
</head>
<body >

<?php
  include'header.php';
?>
<div class="container" id="Projet">   
<div class="row text-center">
      <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
           <h1 data-scroll-reveal="enter from the bottom after 0.2s"  class="header-line">Actualités</h1>
      </div>
</div>

<div class="form-group pull-right">
    <input type="text" class="search form-control" placeholder="What you looking for?">
</div>
<span class="counter pull-right"></span>
<table class="table table-hover table-bordered results">
  <thead>
    <tr>
      <th class="col-md-5 col-xs-5">Publication</th>
      <th class="col-md-4 col-xs-4">Annee</th>
      <th class="col-md-3 col-xs-3">Realisation</th>
    </tr>
    <tr class="warning no-result">
      <td colspan="4"><i class="fa fa-warning"></i> No result</td>
    </tr>
  </thead>
  <tbody>
  <?php
        include'site\connexion.php';
         $req = $db->query('SELECT * FROM  activite');
         while ($donnee = $req->fetch()) { ?>
    <tr>
      <td><?php echo $donnee['Publication']?></td>
      <td><?php echo $donnee['Annee']?></td>
      <td><?php echo $donnee['Realisation']?></td>
    </tr>
    <?php
						}
						?>
  </tbody>
</table>
</div>

  <?php
  include'footer.php';
  ?>

  <script src="assets/js/jquery-1.10.2.js"></script>
    <!--  Core Bootstrap Script -->
    <script src="assets/js/bootstrap.js"></script>
    <!--  Flexslider Scripts --> 
         <script src="assets/js/jquery.flexslider.js"></script>
     <!--  Scrolling Reveal Script -->
    <script src="assets/js/scrollReveal.js"></script>
    <!--  Scroll Scripts --> 
    <script src="assets/js/jquery.easing.min.js"></script>
    <!--  Custom Scripts --> 
         <script src="assets/js/custom.js"></script>
</body>
</html>
