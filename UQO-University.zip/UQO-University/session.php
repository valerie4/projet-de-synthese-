  <div class="home-sec" id="home" >
           <div class="overlay">
           <div class="container">
           <div class="row text-center " >
               <div class="col-lg-12  col-md-12 col-sm-12">
                <div class="flexslider set-flexi" id="main-section" >
                    <ul class="slides move-me">
                    <?php
                            include'site\connexion.php';
                $req = $db->query('SELECT * FROM actualite');
                while ($donnee = $req->fetch()) {
                     ?>
                        <li>
                           <h1><?php echo $donnee['Article']?></h1>
                        </li>
                        <?php
				                		}
					          	?>
                    </ul>
                </div>  
               </div>    
             </div>
          </div>
        </div>
    </div>
<div class="container-fluid" id="Projet">
  <div class="row">
             <div class="row text-center">
                  <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.2s"  class="header-line">Actualités</h1>
                 </div>
             </div>
             <?php
                    include'site\connexion.php';         
                $req = $db->query('SELECT * FROM actualite  ORDER BY idActualite DESC LIMIT 0,3');
                while ($donnee = $req->fetch()) {
                    
                     ?>
    <div class="col-lg-4 col-sm-6 mb-4" >
      <div class="card h-100">
        <a href="#"><img class="card-img-top"  style="width:250p; height:150px; margin:20px;"  src="<?php echo $donnee['image']?>" alt=""></a>
        <div class="card-body">
          <h4 class="card-title ">
            <a href="#"><?php echo $donnee['Lieu_de_conference']?></a>
            <p> Du <?php echo $donnee['Date_de_Presentation']?> au <?php echo $donnee['Date_Fin']?> </p>
          </h4>
          <p> <?php echo $donnee['Article']?> </p>
        </div>
      </div>
    </div>
    <?php
			}
		?>
  </div>
</div>


  <!-- /.row -->
  <!-- Pagination -->
    <!-- Pagination -->
    <div id="block-voirtouteslesactualites" class="block block-block-contentba6b6b57-8e1d-47dd-86e4-402aa89c2a3f">
      <div class="clearfix text-formatted field field--name-body">
            <a href="fildactualite.php" class="button">Voir toutes les actualités</a>
      </div> 
      </div>
 <!--HOME SECTION TAG LINE END-->  
 <div class="container">
           <div class="row" >
                 <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.4s">
                     <div class="about-div">
                     <!-- <i class="fa fa-paper-plane-o fa-4x icon-round-border" ></i> -->
                   <h3 >Projet De Recherche</h3>
                 <hr />
                <hr />
               <a href="projetDeRecherche.php" class="btn btn-info btn-set"  >Projet De Recherche</a>
           </div>
          </div>
            <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.5s">
                     <div class="about-div">
                     <!-- <i class="fa fa-bolt fa-4x icon-round-border" ></i> -->
                      <h3 >Partenaires</h3>
                                <hr />
                                <hr />
                     <a href="partenaire.php" class="btn btn-info btn-set"  >Partenaires</a>
                </div>
            </div>
                 <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.6s">
                     <div class="about-div">
                     <!-- <i class="fa fa-magic fa-4x icon-round-border" ></i> -->
                                 <h3 >Activite</h3>
                       <hr />
                       <hr />

                        <a href="activite.php" class="btn btn-info btn-set"  >Activite</a>
                </div>
            </div>
        </div>
  </div>

             <div id="features-sec" class="container set-pad" >
              <div class="row" >
              <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.5s">
                        <div class="about-div">
                        <!-- <i class="fa fa-bolt fa-4x icon-round-border" ></i> -->
                         <h3 >Collaborateurs</h3>
                                   <hr />
                                   <hr />
                        <a href="Collaborateurs.php" class="btn btn-info btn-set text-center">Collaborateurs</a>
                   </div>
               </div>
               <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.5s">
                        <div class="about-div">
                        <!-- <i class="fa fa-bolt fa-4x icon-round-border" ></i> -->
                         <h3 >Membres</h3>
                                   <hr />
                                   <hr />
                        <a href="membre.php" class="btn btn-info btn-set text-center">Membres</a>
                   </div>
               </div>
                    <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.6s">
                        <div class="about-div">
                        <!-- <i class="fa fa-magic fa-4x icon-round-border" ></i> -->
                                    <h3 >Files d'actualités</h3>
                          <hr />
                          <hr />
                           <a href="fildactualite.php" class="btn btn-info btn-set text-center">Files d'actualités</a>
                   </div>
               </div>
           
                  </div>
                </div> 
  <?php
  
  include'site\connexion.php';

if ( isset($_POST['connexion']))    
{

    $nom = htmlentities(trim($_POST["Nom"]));
    $email = htmlentities(trim($_POST["Email"]));
    $message = htmlentities(trim($_POST["Message"]));


$sql="INSERT INTO subjection VALUES(NULL,:Nom,:Email,:Message)";
$requete=$db->prepare($sql);
$requete->execute(array(

":Nom"=>$nom,
":Email"=>$email,
":Message"=>$message,
      ));  
    }        
  ?>
<div id="contact-sec">
   <div class="overlay">
          <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line" >Une question, un projet ?</h1>
                 </div>
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line" >N'hésitez pas à nous contacter via ce formulaire</h1>
                 </div>
             </div>
             <!--/.HEADER LINE END-->
             <div class="row set-row-pad"  data-scroll-reveal="enter from the bottom after 0.5s" >
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
                 <form class="card-body cardbody-color p-lg-5" method="post" action=""  enctype="multipart/form-data">
                        <div class="form-group">
                        <input class="form-control"  name="Nom" cols="60" rows="5"  placeholder="Nom" required>
                        </div>
                        <div class="form-group">
                        <input type="email" class="form-control" name="Email"  placeholder="Email" required>
                        </div>
                        <div class="form-group">
                        <div class="mb-3">
                           <textarea  cols="30" rows="10" type="text" class="form-control"  name="Message"  placeholder="Message" required></textarea>
                        </div>
                        <div class="form-group text-center">
                        <input type="submit" class="btn btn-info" name="connexion"  value="Envoyer" required/> 
                        </div>
                    </form>
                </div>
               </div>
            </div>
          </div> 
       </div>


<div class="container" id="Projet">
	<div class="row">
  <?php
                include'site\connexion.php';
                $req = $db->query('SELECT * FROM membre ORDER BY idMembre DESC LIMIT 0,4');
                while ($donnee = $req->fetch()) {
                     ?>
	 <div class="col-lg-3 col-md-4 col-sm-6 mb-4" >
      <div class="card h-100" style=" height:500px; width:100%;">
        <a href="#"><img class="card-img-top" src="<?php echo $donnee['image']?>" alt=""></a>
        <div class="card-body" style=" height:500px; width:100%;">
          <h4 class="card-title">
            <a href="#"><?php echo $donnee['Nom']?> <?php echo $donnee['Prenom']?></a>
          </h4>
              <figure class="profile">
                   <img src="<?php echo $donnee['image']?>" class="profile-avatar" alt="">
             </figure>
              <div class="meta">
                   <a  style=" height:600px; width:100%;" ><?php echo $donnee['Profession']?></a>
              </div>
              <div class="card-text">
                    <?php echo $donnee['Ville']?>
               </div>
               <div class="card-footer tab-card-header">
           </div>
            <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
            <li class="nav-item ">
                   <button class="btn btn-warning " style=" margin:10px;">
                           <a href="">Plus de Detail</a>
                    </button>
            </li>
           </ul>
        </div>
      </div>
    </div> 
    <?php
			}
		?>
  </div>
<div id="block-voirtouteslesactualites" class="block block-block-contentba6b6b57-8e1d-47dd-86e4-402aa89c2a3f">
      <div class="clearfix text-formatted field field--name-body">
            <a href="membre.php" class="button">Voir toutes les membres</a>
      </div> 
      </div>