<?php 
	include'connexion.php';
	
	         $req = $db->query('DELETE FROM actualite where idActualite ='.$_GET['id']);
			 header('location:actualite.php');
?>