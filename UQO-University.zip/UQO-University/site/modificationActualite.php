            <?php
                    include'header.php';
            ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
  <?php
          include'connexion.php';
    if ( isset($_POST['connexion'])) {


      $image = $_FILES['image'];
		
      $imageName = $_FILES['image']['name'];
      $imageTmp_name = $_FILES['image']['tmp_name'];
      $imageSize = $_FILES['image']['size'];

      $imageExt = explode('.', $imageName);
      $fileActualExt = strtolower(end($imageExt));
      $allowed = array('jpg','jpeg','png','pdf');


  if($imageSize)
  {
    $imageNameNew = uniqid('',true).".".$fileActualExt;
    $old = $_POST["old_image"];
    
    $old = "image/".explode("image/actue/",$old)[1];
    unlink($old);
    $fileDestination = "image/actue/".$imageNameNew;
    move_uploaded_file($imageTmp_name, $fileDestination);
    $sql='UPDATE actualite SET  image=:image WHERE idActualite='.$_GET['id'];
    $requete=$db->prepare($sql);
    $requete->execute(array(
      ":image"=>" http://localhost/UQO-University/site/".$fileDestination
    ));
  }

        $article = $_POST['Article'];
        $datePresent = $_POST['Date_de_Presentation'];
        $dateFin = $_POST['Date_Fin'];
        $lieu = $_POST['Lieu_de_conference'];
        $req = $db->prepare('UPDATE actualite SET Article = :act,
         Date_de_Presentation = :datp,Date_Fin = :datf,
          Lieu_de_conference = :lieu where idActualite = :id ');
			$req->execute(array(
  				'act' => $article,
  				'datp' => $datePresent,
  				'datf' => $dateFin,
          'lieu' => $lieu,
  				'id' => $_GET['id']));
                  header('location:actu.php');	
        }
            $req = $db->query('SELECT * FROM actualite where idActualite ='.$_GET['id']);
		    while ($donnee = $req->fetch()) {      
  ?>
   <a href="actualite.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Actualite</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action=""  enctype="multipart/form-data">
          <div class="mb-3">
              <input name="Article" class="form-control" cols="60" rows="5"  placeholder="Article" value="<?php echo $donnee['Article']?>" required>
            </div>
            <div class="mb-3">
              <input type="date" class="form-control" name="Date_de_Presentation"  placeholder="Date_de_Presentation" value="<?php echo $donnee['Date_de_Presentation']?>" required>
            </div>
            <div class="mb-3">
              <input type="date" class="form-control"  name="Date_Fin"  placeholder="Date_Fin" value="<?php echo $donnee['Date_Fin']?>" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Lieu_de_conference"  placeholder="Lieu_de_conference" value="<?php echo $donnee['Lieu_de_conference']?>" required>
            </div>

            <div class="mb-3">
                <input class="form-control" type="file" name="image" id="image" value="<?=  $data['image'];?>" >
		        	  <input class="form-control" type="hidden" name="old_image" value="<?=  $data['image'];?>" >

            </div>

 <?php }?>
            <div class="text-center">
              <input type="submit" href="actualite.php" class="btn btn-info" name="connexion"  value="Modifier" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

