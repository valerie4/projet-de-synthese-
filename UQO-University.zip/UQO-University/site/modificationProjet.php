<?php
        include('header.php');
?>

  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <?php
          include'connexion.php';
    if ( isset($_POST['connexion'])) {

      $image = $_FILES['image'];
		
        $imageName = $_FILES['image']['name'];
        $imageTmp_name = $_FILES['image']['tmp_name'];
        $imageSize = $_FILES['image']['size'];
        $imageExt = explode('.', $imageName);
        $fileActualExt = strtolower(end($imageExt));
        $allowed = array('jpg','jpeg','png','pdf');
	

		if($imageSize)
		{
			$imageNameNew = uniqid('',true).".".$fileActualExt;
			$old = $_POST["old_image"];
			
			$old = "image/".explode("image/pro/",$old)[1];
			unlink($old);
			$fileDestination = "image/pro/".$imageNameNew;
			move_uploaded_file($imageTmp_name, $fileDestination);
			$sql='UPDATE projet SET  image=:image WHERE idProjet='.$_GET['id'];
			$requete=$db->prepare($sql);
			$requete->execute(array(
				":image"=>"http://localhost/UQO-University/site/".$fileDestination
			));
		}
        $Titre = $_POST['Titre'];
        $Description = $_POST['Description'];
        $Support = $_POST['Support'];
        $req = $db->prepare('UPDATE projet SET Titre = :Tit,
         Description = :Desc, Support = :Sup
          where idProjet = :id ');
			$req->execute(array(
  				'Tit' => $Titre,
  				'Desc' => $Description,
  				'Sup' => $Support,
  				'id' => $_GET['id']));
          header('location: projet.php');	       
        echo "Modification effectuer avec succes";   
                   
        }
            $req = $db->query('SELECT * FROM projet where idProjet ='.$_GET['id']);
		    while ($donnee = $req->fetch()) {    
      
  ?>
  <a href="projet.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Projet</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action=""  enctype="multipart/form-data">
             <div class="mb-3">
              <input type="text" class="form-control"  name="Titre"  placeholder="Titre" value="<?php echo $donnee['Titre']?>" required>
            </div>
          <div class="mb-3">
              <textarea name="Description" class="form-control" cols="60" rows="5"  placeholder="Description" required><?php echo $donnee['Description']?></textarea>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" name="Support"  placeholder="Support" value="<?php echo $donnee['Support']?>" required>
            </div>
            <div class="mb-3">
                <input class="form-control" type="file" name="image" id="image" value="<?=  $data['image'];?>" >
		       <input class="form-control" type="hidden" name="old_image" value="<?=  $data['image'];?>" >
            </div>
     <?php }?>
            <div class="text-center">
              <input type="submit" href="activite.php" class="btn btn-info" name="connexion"  value="Modifier" required/> 
            </div>
            <div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

