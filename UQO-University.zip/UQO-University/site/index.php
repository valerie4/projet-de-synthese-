<?php
session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>UQO-dashboard</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/dashboard/">

    <link rel="shortcut icon" href="assets\images\logo UQO.png" type="image/vnd.microsoft.icon" />
    <!-- Bootstrap core CSS -->
    <link href="fontawesome-free\js\bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Jason  -->
    <link rel="manifest" href="fontawesome-free\js\manifest.json">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="fontawesome-free/css/dashboard.css">
    <meta name="theme-color" content="#7952b3">   


  </head>
  <body>
  <?php
          if(isset($_POST['connexion'])){
          $_POST['user'] = htmlspecialchars($_POST['user']);
          $_POST['pass'] = htmlspecialchars($_POST['pass']);
          if ( $_POST['user']=='admin' && $_POST['pass']== 'admin') {
            $_SESSION['user'] = $_POST['user'];
            header('location:dashboard.php');
            }
          else
            echo"<mark>Vos identifiants ne correspondent pas</mark>";
        }
        ?>
  <div class="container bt-4">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5 bg-info bt-4">
          <form class="card-body cardbody-color p-lg-5" method="POST">

            <div class="text-center">
              <img src="image\online-3410266_1280.jpg" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                width="200px" alt="profile">
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="user" id="Username" aria-describedby="emailHelp"
                placeholder="User Name" required>
            </div>
            <div class="mb-3">
              <input type="password" class="form-control" name="pass" id="password" placeholder="password" required>
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-success" name="connexion"  value="Connecter-vous" required/> 
            </div>
            <div id="emailHelp" class="form-text text-center mb-5 text-dark">Not
              Registered? <a href="#" class="text-dark fw-bold"> Create an
                Account</a>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
  </body>
</html>
