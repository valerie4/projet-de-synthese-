  <?php
        include'header.php';   
  ?>
  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
  <?php
       include'connexion.php';
if ( isset($_POST['connexion'])) 
    
{
  
          $nom = htmlentities(trim($_POST["Nom"]));
          $email = htmlentities(trim($_POST["Email"]));
          $message = htmlentities(trim($_POST["Message"]));
      
  
      $sql="INSERT INTO subjection VALUES(NULL,:Nom,:Email,:Message)";
      $requete=$db->prepare($sql);
      $requete->execute(array(
  
      ":Nom"=>$nom,
      ":Email"=>$email,
      ":Message"=>$message,
      ));

        echo "Insertion effectuer avec succes";       
    }        
  ?>
  <a href="subjection.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Subjection</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action=""  enctype="multipart/form-data">
          <div class="mb-3">
              <input class="form-control"  name="Nom" cols="60" rows="5"  placeholder="Nom" required>
            </div>
            <div class="mb-3">
              <input type="email" class="form-control" name="Email"  placeholder="Email" required>
            </div>
            <div class="mb-3">
              <textarea  cols="30" rows="10" type="text" class="form-control"  name="Message"  placeholder="Message" required></textarea>
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-info" name="connexion"  value="Enregistrer" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

