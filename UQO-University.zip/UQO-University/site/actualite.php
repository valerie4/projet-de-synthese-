<?php
        include'header.php';
?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <a href="insererActualite.php" type="button" class="btn btn-outline-info">Ajouter</a> 
      <h2 class="text-center">Actualite</h2>
      <div class="table-responsive">
      <table class="table table-striped table-hover table-dark table-bordered table-sm">
      <thead class="text-info text-center">
            <tr>
              <th scope="col">idActualite</th>
              <th scope="col">image</th>
              <th scope="col">Article</th>
              <th scope="col">Date_de_Presentation</th>
              <th scope="col">Date_Fin</th>
              <th scope="col">Lieu_de_conference</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody class="text-warning text-center">
          <?php
                include'connexion.php';
                $req = $db->query('SELECT * FROM  actualite');
                while ($donnee = $req->fetch()) { ?>
              <tr>
              <td> <?php echo $donnee['idActualite']?></td>
              <td><img class="t rounded" src="<?php echo $donnee['image']; ?>" height="100px" width="100px"></td>
              <td> <?php echo $donnee['Article']?></td>
              <td><?php echo $donnee['Date_de_Presentation']?></td>
              <td><?php echo $donnee['Date_Fin']?></td>
              <td><?php echo $donnee['Lieu_de_conference']?></td>
              <td>
              <a href="modificationActualite.php?id=<?php echo $donnee['idActualite']?>" type="button" class="btn btn-outline-warning">Modifier</a> 
              <a href="deleteActualite.php?id=<?php echo $donnee['idActualite']?>" type="button" class="btn btn-outline-danger">Supprimez</a>
              </td>
            </tr>
            <?php
						}
						?>	
          </tbody>
        </table>
      </div>
    </main>
