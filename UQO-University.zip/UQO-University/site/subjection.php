<?php
        include'header.php';
     ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <a href="insererSubjection.php" type="button" class="btn btn-outline-info">Ajouter</a> 
      <h2 class="text-center">Subjection</h2>
      <div class="table-responsive">
        <table class="table table-striped table-hover table-dark table-bordered table-sm">
          <thead class="text-center text-info">
            <tr>
              <th scope="col">idSubjection</th>
              <th scope="col">nom</th>
              <th scope="col">email</th>
              <th scope="col">message</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody class="text-center text-warning">
          <?php
                include'connexion.php';
                $req = $db->query('SELECT * FROM  subjection');
                while ($donnee = $req->fetch()) { ?>
              <tr>
              <td> <?php echo $donnee['idSubjection']?></td>
              <td> <?php echo $donnee['Nom']?></td>
              <td><?php echo $donnee['Email']?></td>
              <td><?php echo $donnee['Message']?></td>
              <td>
              <a href="deleteSubjection.php?id=<?php echo $donnee['idSubjection']?>" type="button" class="btn btn-outline-danger">Supprimez</a>
              </td>
            </tr>
            <?php
						}
						?>	
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<!-- 
    <script src="bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      <script src="feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script> -->
  </body>
</html>
