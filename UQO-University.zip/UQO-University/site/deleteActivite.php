<?php
                include'connexion.php';
	         $req = $db->query('DELETE FROM activite where idActivite ='.$_GET['id']);
	    echo 'Suppression effectuer avec succes';  
	header('location:activite.php');
?>