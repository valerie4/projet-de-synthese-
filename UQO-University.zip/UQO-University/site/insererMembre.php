<?php
        include 'header.php';
      
?>
  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <?php

      include'connexion.php';

    if ( isset($_POST['connexion'])) {
          // Saisie des valeurs d‘entrée
    
         
    
    $image = $_FILES['image'];
		$imageName = $_FILES['image']['name'];
		$imageTmp_name = $_FILES['image']['tmp_name'];
		$imageSize = $_FILES['image']['size'];

		$imageExt = explode('.', $imageName);
		$fileActualExt = strtolower(end($imageExt));
		$allowed = array('jpg','jpeg','png','pdf');
		
			if($imageSize)
			{
				$imageNameNew = uniqid('',true).".".$fileActualExt;
				$fileDestination = 'image/mem/'.$imageNameNew;
				move_uploaded_file($imageTmp_name, $fileDestination);
				

			}	


        $image = 'http://localhost/UQO-University/site/'.$fileDestination;
        $Nom = htmlentities(trim($_POST["Nom"]));
        $Prenom = htmlentities(trim($_POST["Prenom"]));
        $Profession = htmlentities(trim($_POST["Profession"]));
        $Ville = htmlentities(trim($_POST["Ville"]));
		

		$sql="INSERT INTO membre VALUES(NULL,:image,:Nom,:Prenom,:Profession,:Ville)";
		$requete=$db->prepare($sql);
		$requete->execute(array(

		":image"=>$image,
		":Nom"=>$Nom,
		":Prenom"=>$Prenom,
		":Profession"=>$Profession,
		":Ville"=>$Ville
		
		)); 
        echo "Insertion effectuer avec succes";               
      }
  ?>
  <a href="membres.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Membres</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action="" enctype="multipart/form-data">
           <div class="mb-3">
             <input type="text" name="Nom" class="form-control" cols="60" rows="5"  placeholder="Nom" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" name="Prenom"  placeholder="Prenom" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Profession"  placeholder="Profession" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Ville"  placeholder="Ville" required>
            </div>
            <div class="mb-3">
              <input type="file" class="form-control"  name="image"  placeholder="image" required>
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-info" name="connexion"  value="Enregistrer" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

