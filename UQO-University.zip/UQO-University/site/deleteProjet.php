<?php 
	include'connexion.php';
	         $req = $db->query('DELETE FROM projet where idProjet ='.$_GET['id']);
	    echo 'Suppression effectuer avec succes';  
	header('location:projet.php');
?>