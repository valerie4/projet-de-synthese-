<?php
        include'header.php';
     ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <a href="insererPartenaire.php" type="button" class="btn btn-outline-info">Ajouter</a> 
      <h2 class="text-center">Partenaires</h2>
      <div class="table-responsive">
      <table class="table table-striped table-hover table-dark table-bordered table-sm">
        <thead class="text-info text-center">
            <tr>
              <th scope="col">idPartenaire</th>
              <th scope="col">image</th>
              <th scope="col">Prive</th>
              <th scope="col">Institution</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody class="text-warning text-center">
          <?php
                include 'connexion.php';
                $req = $db->query('SELECT * FROM  partenaire');
                while ($donnee = $req->fetch()) { ?>
              <tr>
              <td> <?php echo $donnee['idPartenaire']?></td>
              <td> <img class="t rounded" src="<?php echo $donnee['image']; ?>" height="100px" width="100px"> </td>
              <td> <?php echo $donnee['Prive']?></td>
              <td> <?php echo $donnee['Institution']?></td>
              <td>
              <a href="modificationPartenaire.php?id=<?php echo $donnee['idPartenaire']?>" type="button" class="btn btn-outline-warning">Modifier</a> 
              <a href="deletePartenaire.php?id=<?php echo $donnee['idPartenaire']?>" type="button" class="btn btn-outline-danger">Supprimez</a>
              </td>
            </tr>
            <?php
						}
						?>	
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<!-- 
    <script src="bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

      <script src="feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script> -->
  </body>
</html>
