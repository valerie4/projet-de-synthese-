
<?php
        include'header.php';
      
  ?>
  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
  <?php
    include'connexion.php';
    
    if ( isset($_POST['connexion'])) {
     
          $publication = htmlentities(trim($_POST["Publication"]));
          $Annee = htmlentities(trim($_POST["Annee"]));
          $realisation = htmlentities(trim($_POST["Realisation"]));
          
      
  
      $sql="INSERT INTO activite VALUES(NULL,:Publication,:Annee,:Realisation)";
      $requete=$db->prepare($sql);
      $requete->execute(array(
  
      ":Publication"=>$publication,
      ":Annee"=>$Annee,
      ":Realisation"=>$realisation,
      ));

        echo "Insertion effectuer avec succes";               
      }
  ?>
  <a href="activite.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Activite</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action=""  enctype="multipart/form-data">
          <div class="mb-3">
              <textarea type="text" name="Publication" class="form-control" cols="60" rows="5"  placeholder="Publication" required></textarea>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" name="Realisation"  placeholder="Realisation" required>
            </div>
            <div class="mb-3">
              <input type="date" class="form-control"  name="Annee"  placeholder="Annee" required>
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-info" name="connexion"  value="Enregistrer" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

