<?php
        include  'header.php';
      
  ?>
  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <?php
          include'connexion.php';
    if ( isset($_POST['connexion'])) {

      $image = $_FILES['image'];
		
        $imageName = $_FILES['image']['name'];
        $imageTmp_name = $_FILES['image']['tmp_name'];
        $imageSize = $_FILES['image']['size'];

        $imageExt = explode('.', $imageName);
        $fileActualExt = strtolower(end($imageExt));
        $allowed = array('jpg','jpeg','png','pdf');
	

		if($imageSize)
		{
			$imageNameNew = uniqid('',true).".".$fileActualExt;
			$old = $_POST["old_image"];
			
			$old = "image/".explode("image/mem/",$old)[1];
			unlink($old);
			$fileDestination = "image/mem/".$imageNameNew;
			move_uploaded_file($imageTmp_name, $fileDestination);
			$sql='UPDATE membre SET  image=:image WHERE idMembre='.$_GET['id'];
			$requete=$db->prepare($sql);
			$requete->execute(array(
				":image"=>"http://localhost/UQO-University/site/".$fileDestination
			));
		}

        $nom = $_POST['Nom'];
        $prenom = $_POST['Prenom'];
        $adresse = $_POST['Adresse'];
        $ville = $_POST['Ville'];
        $req = $db->prepare('UPDATE membre SET Nom = :nom,
         Prenom = :prenom, Adresse = :adresse,
         Ville = :ville where idMembre = :id ');
			$req->execute(array(
  				'nom' => $nom,
  				'prenom' => $prenom,
  				'adresse' => $adresse,
          'ville' => $ville,
  				'id' => $_GET['id']));
            header('location:membres.php');	
        }
            $req = $db->query('SELECT * FROM membre where idMembre ='.$_GET['id']);
		    while ($donnee = $req->fetch()) {      
  ?>
  <a href="membres.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Membres</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action="" enctype="multipart/form-data">
           <div class="mb-3">
             <input type="text" name="Nom" class="form-control" cols="60" rows="5"  placeholder="Nom" value="<?php echo $donnee['Nom']?>" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" name="Prenom"  placeholder="Prenom" value="<?php echo $donnee['Prenom']?>" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Adresse"  placeholder="Adresse" value="<?php echo $donnee['Adresse']?>" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Ville"  placeholder="Ville" value="<?php echo $donnee['Ville']?>" required>
            </div>
            <div class="mb-3">
                <input class="form-control" type="file" name="image" id="image" value="<?=  $data['image'];?>" >
		        	  <input class="form-control" type="hidden" name="old_image" value="<?=  $data['image'];?>" >

            </div>
            
      <?php }?>
            <div class="text-center">
              <input type="submit" class="btn btn-info" name="connexion"  value="Modifier" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

