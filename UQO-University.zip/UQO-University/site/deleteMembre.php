<?php 
	include'connexion.php';
	         $req = $db->query('DELETE FROM membre where idMembre ='.$_GET['id']);
	    echo 'Suppression effectuer avec succes';  
	header('location:membres.php');
?>