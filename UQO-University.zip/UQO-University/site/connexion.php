 <?php
#Connection a la base de donnees 
/**
 */
  try {
 	$db= new PDO('mysql:host=localhost;dbname=database', 'root','',
  		array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
  } 
//S'il ya erreur il sera redirictionner vers ici
 catch (Exception $e) {
        die('Erreur : '. $e -> getMessage());	
 }

?>