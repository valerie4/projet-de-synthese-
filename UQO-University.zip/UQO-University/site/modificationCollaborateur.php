   <?php
       include('header.php');  
   ?>

  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
  <?php
          include'connexion.php';
    if ( isset($_POST['connexion'])) {

      $image = $_FILES['image'];
		
      $imageName = $_FILES['image']['name'];
      $imageTmp_name = $_FILES['image']['tmp_name'];
      $imageSize = $_FILES['image']['size'];

      $imageExt = explode('.', $imageName);
      $fileActualExt = strtolower(end($imageExt));
      $allowed = array('jpg','jpeg','png','pdf');

  if($imageSize)
  {
    $imageNameNew = uniqid('',true).".".$fileActualExt;
    $old = $_POST["old_image"];
    
    $old = "image/".explode("image/call/",$old)[1];
    unlink($old);
    $fileDestination = "image/call/".$imageNameNew;
    move_uploaded_file($imageTmp_name, $fileDestination);
    $sql='UPDATE collaborateur SET  image=:image WHERE idCollaborateur='.$_GET['id'];
    $requete=$db->prepare($sql);
    $requete->execute(array(
      ":image"=>" http://localhost/UQO-University/site/".$fileDestination
    ));
  }
        $nom = $_POST['Nom'];
        $fonction = $_POST['Fonction'];
        $instituion = $_POST['Instituion'];
        $req = $db->prepare('UPDATE collaborateur SET Nom = :nom,
         Fonction = :fonc, Instituion = :inst
          where idCollaborateur = :id ');
			$req->execute(array(
  				'nom' => $nom,
  				'fonc' => $fonction,
  				'inst' => $instituion,
  				'id' => $_GET['id']));
                  header('location:collaborateur.php');	
        }
            $req = $db->query('SELECT * FROM collaborateur where idCollaborateur ='.$_GET['id']);
		    while ($donnee = $req->fetch()) {      
  ?>
   <a href="collaborateur.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Collaborateurs</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action="" enctype="multipart/form-data">
            <div class="mb-3"> 
             <input type="text" name="Nom" class="form-control" cols="60" rows="5"  placeholder="Nom" value="<?php echo $donnee['Nom']?>" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" name="Fonction"  placeholder="Fonction" value="<?php echo $donnee['Fonction']?>" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Instituion"  placeholder="Instituion" value="<?php echo $donnee['Instituion']?>" required>
            </div>
            <div class="mb-3">
                <input class="form-control" type="file" name="image" id="image" value="<?=  $data['image'];?>" >
		        	  <input class="form-control" type="hidden" name="old_image" value="<?=  $data['image'];?>" >
            </div>

            <div class="text-center">
              <input type="submit"  class="btn btn-info" name="connexion"  value="Modifier" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

<?php }?>