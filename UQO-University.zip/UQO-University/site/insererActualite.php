<?php
        include'header.php';
      
  ?>
  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <?php

    include'connexion.php';
    
    if ( isset($_POST['connexion'])) {

      $image = $_FILES['image'];
      $imageName = $_FILES['image']['name'];
      $imageTmp_name = $_FILES['image']['tmp_name'];
      $imageSize = $_FILES['image']['size'];
  
      $imageExt = explode('.', $imageName);
      $fileActualExt = strtolower(end($imageExt));
      $allowed = array('jpg','jpeg','png','pdf');
      
        if($imageSize)
        {
          $imageNameNew = uniqid('',true).".".$fileActualExt;
          $fileDestination = 'image/actue/'.$imageNameNew;
          move_uploaded_file($imageTmp_name, $fileDestination);
        
        }	

          $image = 'http://localhost/UQO-University/site/'.$fileDestination;
          $Article = htmlentities(trim($_POST["Article"]));
          $Date_de_Presentation = htmlentities(trim($_POST["Date_de_Presentation"]));
          $Date_Fin = htmlentities(trim($_POST["Date_Fin"]));
          $Lieu_de_conference = htmlentities(trim($_POST["Lieu_de_conference"]));
      
  
      $sql="INSERT INTO actualite VALUES(NULL,:image,:Article,:Date_de_Presentation,:Date_Fin,:Lieu_de_conference)";
      $requete=$db->prepare($sql);
      $requete->execute(array(
  
      ":image"=>$image,
      ":Article"=>$Article,
      ":Date_de_Presentation"=>$Date_de_Presentation,
      ":Date_Fin"=>$Date_Fin,
      ":Lieu_de_conference"=>$Lieu_de_conference
  
      ));

       echo "Insertion effectuer avec succes";               
    }
  ?>
   <a href="actualite.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Actualite</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action="" enctype="multipart/form-data" >
          <div class="mb-3">
              <textarea name="Article" class="form-control" cols="60" rows="5"  placeholder="Article" required></textarea>
            </div>
            <div class="mb-3">
              <input type="date" class="form-control" name="Date_de_Presentation"  placeholder="Date_de_Presentation" required>
            </div>
            <div class="mb-3">
              <input type="date" class="form-control"  name="Date_Fin"  placeholder="Date_Fin" required>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Lieu_de_conference"  placeholder="Lieu_de_conference" required>
            </div>
            <div class="mb-3">
              <input type="file" class="form-control"  name="image"  placeholder="image" required>
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-info" name="connexion"  value="Enregistrer" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

