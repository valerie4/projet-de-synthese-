<?php
        include'header.php';
      
  ?>
  <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <?php
          include'connexion.php';
    if ( isset($_POST['connexion'])) {

      $image = $_FILES['image'];
      $imageName = $_FILES['image']['name'];
      $imageTmp_name = $_FILES['image']['tmp_name'];
      $imageSize = $_FILES['image']['size'];
  
      $imageExt = explode('.', $imageName);
      $fileActualExt = strtolower(end($imageExt));
      $allowed = array('jpg','jpeg','png','pdf');
      
        if($imageSize)
        {
          $imageNameNew = uniqid('',true).".".$fileActualExt;
          $fileDestination = 'image/pro/'.$imageNameNew;
          move_uploaded_file($imageTmp_name, $fileDestination);
      
        }	

        $image = 'http://localhost/UQO-University/site/'.$fileDestination;
        $Titre = htmlentities(trim($_POST["Titre"]));
        $Description = htmlentities(trim($_POST["Description"]));
        $Support = htmlentities(trim($_POST["Support"]));
    

    $sql="INSERT INTO projet VALUES(NULL,:image,:Titre,:Description,:Support)";
    $requete=$db->prepare($sql);
    $requete->execute(array(

    ":image"=>$image,
    ":Titre"=>$Titre,
    ":Description"=>$Description,
    ":Support"=>$Support,
    ));

        echo "Insertion effectuer avec succes";               
    }
  ?>
   <a href="projet.php" type="button" class="btn btn-outline-danger">Retour</a> 
    <h2 class="text-center">Projet</h2>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card my-5">
          <form class="card-body cardbody-color p-lg-5" method="post" action="" enctype="multipart/form-data">
            <div class="mb-3">
             <input type="text" name="Titre" class="form-control" cols="60" rows="5"  placeholder="Titre" required>
            </div>
            <div class="mb-3">
              <textarea type="text" class="form-control" name="Description"  placeholder="Description" cols="30" rows="10"></textarea>
            </div>
            <div class="mb-3">
              <input type="text" class="form-control"  name="Support"  placeholder="Support" required>
            </div>
            <div class="mb-3">
              <input type="file" class="form-control"  name="image"  placeholder="image" required>
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-info" name="connexion"  value="Enregistrer" required/> 
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

