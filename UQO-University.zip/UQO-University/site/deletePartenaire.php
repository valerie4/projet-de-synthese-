<?php 
	include'connexion.php';
	         $req = $db->query('DELETE FROM partenaire where idPartenaire ='.$_GET['id']);
	    echo 'Suppression effectuer avec succes';  
	header('location:partenaire.php');
?>