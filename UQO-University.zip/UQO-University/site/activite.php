    <?php
        include 'header.php';
    ?>
   
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <a href="insererActivite.php" type="button" class="btn btn-outline-info">Ajouter</a> 
      <h2 class="text-center">Activite</h2>
      <div class="table-responsive">
      <table class="table table-striped table-hover table-dark table-bordered table-sm">
      <thead class="text-info text-center">
            <tr>
              <th scope="col">idActivite</th>
               <th scope="col">Annee</th>
             <th scope="col">Publication</th>
              <th scope="col">Realisation</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody class="text-warning text-center">
            <?php
                include'connexion.php';
                $req = $db->query('SELECT * FROM  activite');
                while ($donnee = $req->fetch()) { ?>
              <tr>
              <td> <?php echo $donnee['idActivite']?></td>
              <td> <?php echo $donnee['Annee']?></td>
              <td> <?php echo $donnee['Publication']?></td>
              <td><?php echo $donnee['Realisation']?></td>
              <td>
                <a href="modificationActivite.php?id=<?php echo $donnee['idActivite']?>" type="button"  class="btn btn-outline-warning">Modifier</a>
                 <a href="deleteActivite.php?id=<?php echo $donnee['idActivite']?>" type="button" class="btn btn-outline-danger">Supprimez</a>
              </td>
            </tr>
            <?php
						}
						?>	
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>
  </body>
</html>
