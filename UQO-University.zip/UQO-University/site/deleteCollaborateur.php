<?php 
	include'connexion.php';
	
	         $req = $db->query('DELETE FROM collaborateur where idCollaborateur ='.$_GET['id']);
	    echo 'Suppression effectuer avec succes';  
	header('location:collaborateur.php');
?>