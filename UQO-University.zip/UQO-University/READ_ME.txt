**********************************
fichier de configuration 
site\connexion.php 

configuration
host:localhost
password:
utilisateur:root
db:database