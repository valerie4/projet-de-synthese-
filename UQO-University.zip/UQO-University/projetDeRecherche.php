<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>UQO-University</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME CSS -->
<link rel="shortcut icon" href="assets\images\UQO-Univ.png" type="image/vnd.microsoft.icon" />

<link href="assets/css/font-awesome.min.css" rel="stylesheet" />
     <!-- FLEXSLIDER CSS -->
<link href="assets/css/flexslider.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />    
  <!-- Google	Fonts -->
  <link href="assets/css/styles.css" rel="stylesheet" />    

</head>
<body >
<?php
  include'header.php';
?>
<!-- Page Content -->
<div class="container" id="Projet">
    <!-- Project One -->
    <div class="row">
             <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.2s"  class="header-line">Projets</h1>
                 </div>
             </div>
             <?php
                include'site\connexion.php';
                $req = $db->query('SELECT * FROM projet');
                while ($donnee = $req->fetch()) {
                     ?>
      <div class="col-md-7">
        <a href="#">
          <img class="img-fluid rounded mb-3 mb-md-0" style="width:300px; height:50%; margin:20px; border: 1px #0000;" src="<?php echo $donnee['image']?>" alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3><?php echo $donnee['Titre']?></h3>
        <p><?php echo $donnee['Description']?></p>
        <p><?php echo $donnee['Support']?></p>
        <a class="btn btn-primary" href="#">View Project</a>
      </div>
    <?php
			}
		?>
    </div>
  </div>
 
  
  <?php
  include'footer.php';
  ?>
  <!--  Jquery Core Script -->
  <script src="assets/js/jquery-1.10.2.js"></script>
    <!--  Core Bootstrap Script -->
    <script src="assets/js/bootstrap.js"></script>
    <!--  Flexslider Scripts --> 
         <script src="assets/js/jquery.flexslider.js"></script>
     <!--  Scrolling Reveal Script -->
    <script src="assets/js/scrollReveal.js"></script>
    <!--  Scroll Scripts --> 
    <script src="assets/js/jquery.easing.min.js"></script>
    <!--  Custom Scripts --> 
         <script src="assets/js/custom.js"></script>
</body>
</html>
