<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>UQO-University</title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME CSS -->
<link rel="shortcut icon" href="assets\images\UQO-Univ.png" type="image/vnd.microsoft.icon" />
<link href="assets/css/font-awesome.min.css" rel="stylesheet" />
     <!-- FLEXSLIDER CSS -->
<link href="assets/css/flexslider.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />    
  <!-- Google	Fonts -->
  <link href="assets/css/styles.css" rel="stylesheet" />    
  <!-- Google	Fonts -->
<link rel='preload'  media="all"  href="assets\css\css_nGDXBSF1iZsNPsaK-pGORnXqO-nsUQ0G3Xo42QT8v_Q.css" as='style' onload="this.rel='stylesheet'"  /><noscript><link rel="stylesheet" media="all" href="/sites/default/files/css/css_nGDXBSF1iZsNPsaK-pGORnXqO-nsUQ0G3Xo42QT8v_Q.css" /></noscript>
<link rel="stylesheet" href="assets\css\jquery.dataTables.min.css">
<link rel="stylesheet" media="all" href="assets\css\responsive.dataTables.min.css" />
<link rel='preload'  media="all"  href="assets\css\css__ARqGcT6Erq-1_0rF0WDjJRX8-4vigWUbNLwqYmD4Go.css" as='style' onload="this.rel='stylesheet'"  /><noscript><link rel="stylesheet" media="all" href="/sites/default/files/css/css__ARqGcT6Erq-1_0rF0WDjJRX8-4vigWUbNLwqYmD4Go.css" /></noscript>
<link rel='preload'  media="all"  href="assets\css\css_ykgblwjj87nIthzu7uTWBmCWe4Gxc_xxUv67tb5CE_I.css" as='style' onload="this.rel='stylesheet'"  /><noscript><link rel="stylesheet" media="all" href="/sites/default/files/css/css_ykgblwjj87nIthzu7uTWBmCWe4Gxc_xxUv67tb5CE_I.css" /></noscript>

</head>
<body >

<?php
  include'header.php';
?>
     
    
<!-- Page Content -->
<div class="container" id="Projet">
  <div class="row">
  <div class="row text-center" >
      <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
          <h1 data-scroll-reveal="enter from the bottom after 0.2s"  class="header-line">Collaborateurs</h1>
      </div>
</div>
           <?php
                include'site\connexion.php';
                $req = $db->query('SELECT * FROM  collaborateur');
                while ($donnee = $req->fetch()) { ?>
    <div class="col-lg-3 col-md-4 col-sm-6 mb-4" >
      <div class="card h-100" style=" height:500px; width:100%;">
        <a href="#"><img class="card-img-top" src="<?php echo $donnee['image']?>" alt=""></a>
        <div class="card-body" style=" height:500px; width:100%;">
          <h4 class="card-title">
            <a href="#"><?php echo $donnee['Nom']?></a>
          </h4>
              <figure class="profile">
                   <img src="<?php echo $donnee['image']?>" class="profile-avatar" alt="">
             </figure>
              <div class="meta">
                   <a  style=" height:600px; width:100%;" ><?php echo $donnee['Fonction']?></a>
              </div>
              <div class="card-text">
              <?php echo $donnee['Instituion']?>
               </div>
               <div class="card-footer tab-card-header">
           </div>
            <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
            <li class="nav-item ">
                   <button class="btn btn-warning " style=" margin:10px;">
                           <a href="">Plus de Detail</a>
                    </button>
            </li>
           </ul>
        </div>
      </div>
    </div> 
    <?php
			}
		?>
  </div>
  <!-- /.row -->


  <?php
  include'footer.php';
  ?>
  <script type="application/json" data-drupal-selector="drupal-settings-json">{"path":{"baseUrl":"\/","scriptPath":null,"pathPrefix":"","currentPath":"recherche\/publications","currentPathIsAdmin":false,"isFront":false,"currentLanguage":"fr"},"pluralDelimiter":"\u0003","suppressDeprecationErrors":true,"tarteocitron":{"config":{"cdn":"\/libraries\/tarteaucitron.js\/","language":"fr","privacyurl":"","hashtag":"#tarteaucitron","cookiename":"tarteaucitron","orientation":"bottom","groupServices":null,"showalertsmall":false,"cookieslist":false,"closepopup":null,"showicon":false,"iconposition":null,"adblocker":false,"denyallcta":null,"acceptallcta":true,"highprivacy":true,"handlebrowserdntrequest":false,"removecredit":false,"moreinfolink":true,"useexternalcss":false,"useexternaljs":null,"bodyPosition":null,"readmorelink":null,"mandatory":null,"custom_text":"{}","services":""}},"ajaxTrustedUrl":{"form_action_p_pvdeGsVG5zNF_XLGPTvYSKCf43t8qZYSwcfZl2uzM":true,"\/recherche":true},"antibot":{"forms":{"webform-submission-newsletter-add-form":{"id":"webform-submission-newsletter-add-form","key":"HD3_p7hENKgN2VAq0XhcLwnegKcS0gqniGRhZ8ZX664"}}},"publications":{"url":"https:\/\/www.labri.fr\/sites\/default\/files\/publications\/export.json","last_year":2005,"abbr":{"SR":"Soutien Recherche","FINANCE":"Equipe Finance","ADMIN":"Equipe Administrative","EQSYS":"Equipe Syst\u00e8mes \u0026 R\u00e9seaux","I\u0026S":"Image et son","MANIOC":"Manioc","TAD":"Traitement et Analyse de Donn\u00e9es","SATANAS":"Supports et algorithmes pour les applications num\u00e9riques hautes performances","AAHP":"Algorithmes et Applications Hautes Performances","SEHP":"Supports \u00c9x\u00e9cutifs Haute Performance","SED":"Syst\u00e8mes et Donn\u00e9es","BKB":"Bench to Knowledge and Beyond","PROGRESS":"Programmation, r\u00e9seaux et syst\u00e8mes","M2F":"M\u00e9thodes et Mod\u00e8les Formels","MTV":"Mod\u00e8les \u0026 Technologies pour la V\u00e9rification","RATIO":"Raisonnement sur les donn\u00e9es, les connaissances et les contraintes","LX":"Fondements logiques du calcul","DART":"D\u00e9cision et apprentissage : de la th\u00e9orie aux applications robotiques","COMBALGO":"Combinatoire et algorithmique","CI":"Combinatoire et Interactions","ALGODIST":"Algorithmique Distribu\u00e9e","GO":"Graphes et Optimisation"}},"user":{"uid":0,"permissionsHash":"bb5301ecd937d9348b204ba54fb563d54aa4b329303646471323bb44cb44cac4"}}</script>
  <script src="assets\js\js fIF-vH0R9ozdryofkoEII0WRYtxeOTWuX7TfpePPuAo\js_fIF-vH0R9ozdryofkoEII0WRYtxeOTWuX7TfpePPuAo.js"></script>
  <script src="assets\js\js 7NSpC xW9fQyMT6FDCIvZmORmzzl1amIhErP6ubas9w\js_7NSpC_xW9fQyMT6FDCIvZmORmzzl1amIhErP6ubas9w.js"></script>
  <script src="assets\js\jquery dataTables min\jquery.dataTables.min.js"></script>
  <script src="assets\js\dataTables responsive min\dataTables.responsive.min.js"></script>
  <script src="assets\js\js OIt 1WJzfkyYyAYKItJAutvWw2h1hJeVWJwdSC0IbbY\js_OIt_1WJzfkyYyAYKItJAutvWw2h1hJeVWJwdSC0IbbY.js"></script>
    <!--  Jquery Core Script -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!--  Core Bootstrap Script -->
      <script src="assets/js/bootstrap.js"></script>
      <!--  Flexslider Scripts --> 
           <script src="assets/js/jquery.flexslider.js"></script>
       <!--  Scrolling Reveal Script -->
      <script src="assets/js/scrollReveal.js"></script>
      <!--  Scroll Scripts --> 
      <script src="assets/js/jquery.easing.min.js"></script>
      <!--  Custom Scripts --> 
           <script src="assets/js/custom.js"></script>
  </body>
  </html>
  