<div class="container-fluid" class=" style:background: #2d3246;" id="Projet">

             <div class="row set-row-pad"  > 
             <div class="col-lg-4 col-md-4 col-sm-4 " data-scroll-reveal="enter from the bottom after 0.4s">
             <h2 ><strong>Gatineau</strong></h2>
            <hr />
            <div>
                <h4>283, boulevard Alexandre-Taché</h4>
                <h4>C.P. 1250, succursale Hull</h4>
                <h4><strong>Gatineau (Québec) Canada</h4>
                <h4><strong>J8X 3X7</h4>
                <hr />
                   <div>
                        <h4><strong>Téléphone:</strong>  819 595-3900 </h4>
                        <h4><strong>Sans frais: </strong>1 800 567-1283</h4>
                    </div>
            </div>
            </div>
             <div class="col-lg-4 col-md-4 col-sm-4  " data-scroll-reveal="enter from the bottom after 0.4s">
             <h2 ><strong>Saint-Jérôme</strong></h2>
             <hr>
             <div>
                <h4>5, rue Saint-Joseph</h4>
                <h4>Saint-Jérôme (Québec) Canada</h4>
                <h4><strong>J8X 3X7</h4>
                <hr />
                   <div>
                        <h4><strong>Téléphone:</strong>  450 530-7616 </h4>
                        <h4><strong>Sans frais: </strong>1 800 567-1283</h4>
                    </div>
            </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-4 " data-scroll-reveal="enter from the bottom after 0.4s">
                    <h2 ><strong>Connectivité sociale</strong></h2>
                    <hr />
                    <div class="row">
                          <div class="col-sm-3">
                          <a href="https://www.facebook.com/Universite.Quebec.Outaouais"><img src="assets/img/Social/facebook.png" alt="" /> </a>
                          </div>
                          <div class="col-sm-3">
                          <a href="https://uqo.ca/"> <img src="assets/img/Social/google-plus.png" alt="" /></a>
                          </div>
                          <div class="col-sm-3">
                          <a href="https://mobile.twitter.com/home"><img src="assets/img/Social/twitter.png" alt="" /></a>
                          </div>
                          <div class="col-sm-3">
                          <a href="https://instagram.com/uqo_officiel?utm_medium=copy_link"><img src="assets\img\Social\instagram.jpg" alt="" /></a>
                          </div>
                    </div>
                </div>
            </div>
      </div>
	<!-- ./Footer -->
  