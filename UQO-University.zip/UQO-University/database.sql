-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 17 déc. 2021 à 00:06
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `database`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

DROP TABLE IF EXISTS `activite`;
CREATE TABLE IF NOT EXISTS `activite` (
  `idActivite` int(11) NOT NULL AUTO_INCREMENT,
  `Publication` varchar(255) DEFAULT NULL,
  `Annee` date NOT NULL,
  `Realisation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idActivite`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `activite`
--

INSERT INTO `activite` (`idActivite`, `Publication`, `Annee`, `Realisation`) VALUES
(54, 'Olivier Bernardi, Mireille Bousquet-M&eacute;lou, Kilian Raschel. Counting quadrant walks via Tutte\'s invariant method. Combinatorial Theory, In press. (hal-01577762)', '2021-12-15', 'COMBALGO'),
(55, 'Alin Bostan, Mireille Bousquet-M&eacute;lou, Stephen Melczer. Counting walks with large steps in an orthant. Journal of the European Mathematical Society, European Mathematical Society, 2021, 23 (7), pp.2221-2297. (hal-01802706)', '2021-12-31', 'COMBALGO');

-- --------------------------------------------------------

--
-- Structure de la table `actualite`
--

DROP TABLE IF EXISTS `actualite`;
CREATE TABLE IF NOT EXISTS `actualite` (
  `idActualite` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(200) NOT NULL,
  `Article` varchar(255) DEFAULT NULL,
  `Date_de_Presentation` date DEFAULT NULL,
  `Date_Fin` date DEFAULT NULL,
  `Lieu_de_conference` varchar(255) NOT NULL,
  PRIMARY KEY (`idActualite`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `actualite`
--

INSERT INTO `actualite` (`idActualite`, `image`, `Article`, `Date_de_Presentation`, `Date_Fin`, `Lieu_de_conference`) VALUES
(9, ' http://localhost/UQO-University/site/image/actue/61ba03026086a0.19822807.jpg', 'Interview dâ€™Olivier Ly, le 10/12/2021, Ã  TV7 matin, au sujet du forum NAIA.R (IA et informatique), qui a lieu du 9 au 11/12, au Hangar 14 (Bx).', '2021-12-14', '2021-12-31', 'TV7 matin : Interview Olivier Ly'),
(10, 'http://localhost/UQO-University/site/image/actue/61b937f2671114.61861806.jpg', 'Le CL (Conseil de Laboratoire) du LaBRI vote &agrave; l&rsquo;unanimit&eacute; une motion relative au vote &eacute;lectronique &agrave; l&rsquo;universit&eacute; de Bordeaux.', '2021-11-29', '2021-12-01', 'Motion au sujet du vote &eacute;lectronique &agrave; l&rsquo;universit&eacute;'),
(15, 'http://localhost/UQO-University/site/image/actue/61ba53a483cfa8.51254595.jpg', 'La SIF organise 2 demi-journ&eacute;es virtuelles, gratuites mais sur inscription, sur les plateformes mat&eacute;rielles pour la s&eacute;curit&eacute;. Dates : 14 et 15/10/2021.', '2021-12-17', '2021-12-30', 'Plateformes mat&eacute;rielles pour la s&eacute;curit&eacute;'),
(13, 'http://localhost/UQO-University/site/image/actue/61b9389e227ba4.04569242.jpg', 'La SIF organise 2 demi-journ&eacute;es virtuelles, gratuites mais sur inscription, sur les plateformes mat&eacute;rielles pour la s&eacute;curit&eacute;. Dates : 14 et 15/10/2021.', '2021-12-16', '2021-12-31', 'Plateformes mat&eacute;rielles pour la s&eacute;curit&eacute;'),
(14, 'http://localhost/UQO-University/site/image/actue/61b938b90c05c0.91596173.png', 'Intervention de Fr&eacute;d&eacute;ric Mazoit dans le cadre de la F&ecirc;te de la Science et le circuit Bordelais. Cette ann&eacute;e encore, cette manifestation se fait &laquo; hors les murs &raquo; du LaBRI', '2021-12-24', '2021-12-27', 'F&ecirc;te de la science');

-- --------------------------------------------------------

--
-- Structure de la table `collaborateur`
--

DROP TABLE IF EXISTS `collaborateur`;
CREATE TABLE IF NOT EXISTS `collaborateur` (
  `idCollaborateur` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(200) NOT NULL,
  `Nom` varchar(255) DEFAULT NULL,
  `Fonction` varchar(255) DEFAULT NULL,
  `Instituion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idCollaborateur`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `collaborateur`
--

INSERT INTO `collaborateur` (`idCollaborateur`, `image`, `Nom`, `Fonction`, `Instituion`) VALUES
(9, 'http://localhost/UQO-University/site/image/call/61bb3520cd8bb6.92757371.jpg', 'Ilham Benyahia', 'Professeure au D&eacute;partement d&rsquo;informatique et d\'ing&eacute;nierie', 'Laboratoire de cyberpsychologie'),
(10, 'http://localhost/UQO-University/site/image/call/61bb354a5bec31.30764615.jpg', 'Rokia Missaoui', 'Professeure au D&eacute;partement d&rsquo;informatique et d&rsquo;ing&eacute;nierie', 'Professeure au D&eacute;partement d&rsquo;informatique et d&rsquo;ing&eacute;nierie'),
(11, 'http://localhost/UQO-University/site/image/call/61bb3571255381.52552200.jpg', 'Martin Lauzier', 'Titulaire de la chaire Addoceo', 'D&eacute;partement de relations industrielles de l&rsquo;UQO.');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE IF NOT EXISTS `membre` (
  `idMembre` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `Nom` varchar(255) DEFAULT NULL,
  `Prenom` varchar(255) DEFAULT NULL,
  `Profession` varchar(255) DEFAULT NULL,
  `Ville` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idMembre`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`idMembre`, `image`, `Nom`, `Prenom`, `Profession`, `Ville`) VALUES
(41, 'http://localhost/UQO-University/site/image/mem/61bad63b8fea44.36412218.jpg', 'Chiasson', 'Guy', 'Professeur au D&eacute;partement des sciences sociales', 'Outaouais'),
(36, 'http://localhost/UQO-University/site/image/mem/61ba52d23b9a68.31659711.jpg', 'Zogning', 'F&eacute;lix', 'ï»¿ï»¿Professeur au D&eacute;partement des sciences comptables', 'Quebec'),
(39, 'http://localhost/UQO-University/site/image/mem/61ba542368ec61.95116360.jpg', 'Laberge', 'Martin', 'Professeur au D&eacute;partement des sciences sociales', 'Outaouais'),
(38, 'http://localhost/UQO-University/site/image/mem/61ba53575e6c19.31890589.jpg', 'Laberge', 'Martin', 'Professeur au D&eacute;partement des sciences sociales', 'Outaouais');

-- --------------------------------------------------------

--
-- Structure de la table `partenaire`
--

DROP TABLE IF EXISTS `partenaire`;
CREATE TABLE IF NOT EXISTS `partenaire` (
  `idPartenaire` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(200) NOT NULL,
  `Prive` varchar(255) NOT NULL,
  `Institution` varchar(255) NOT NULL,
  PRIMARY KEY (`idPartenaire`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `partenaire`
--

INSERT INTO `partenaire` (`idPartenaire`, `image`, `Prive`, `Institution`) VALUES
(22, 'http://localhost/UQO-University/site/image/par/61b9eb47be99a0.30649238.jpg', 'Financement FEDER de la plateforme LSD (Lab In The Sky with Data)', 'Financement FEDER de la plateforme LSD (Lab In The Sky with Data)'),
(23, 'http://localhost/UQO-University/site/image/par/61bb30c6546c46.77121277.jpg', 'TV7 matin : Interview Olivier Ly', 'La chaire Mobilit&eacute; et Transports Intelligents, port&eacute;e par Mohamed Mosbah, vient de remporter le prix &quot;Recherche et Innovation 2021&quot; de la Fondation Bordeaux Universit&eacute; &agrave;'),
(24, 'http://localhost/UQO-University/site/image/par/61bb30d970c9d6.15127416.jpg', 'Motion au sujet du vote &eacute;lectronique &agrave; l&rsquo;universit&eacute;', 'Le CL (Conseil de Laboratoire) du LaBRI vote &agrave; l&rsquo;unanimit&eacute; une motion relative au vote &eacute;lectronique &agrave; l&rsquo;universit&eacute; de Bordeaux.'),
(25, 'http://localhost/UQO-University/site/image/par/61bb30ed9bbc25.19682354.jpg', 'F&ecirc;te de la science', 'Intervention de Fr&eacute;d&eacute;ric Mazoit dans le cadre de la F&ecirc;te de la Science et le circuit Bordelais. Cette ann&eacute;e encore, cette manifestation se fait &laquo; hors les murs &raquo; du LaBRI'),
(26, 'http://localhost/UQO-University/site/image/par/61bb30fe91e2a7.92987721.jpg', 'Plateformes mat&eacute;rielles pour la s&eacute;curit&eacute;', 'La SIF organise 2 demi-journ&eacute;es virtuelles, gratuites mais sur inscription, sur les plateformes mat&eacute;rielles pour la s&eacute;curit&eacute;. Dates : 14 et 15/10/2021.');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

DROP TABLE IF EXISTS `projet`;
CREATE TABLE IF NOT EXISTS `projet` (
  `idProjet` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `Titre` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Support` varchar(255) NOT NULL,
  PRIMARY KEY (`idProjet`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `projet`
--

INSERT INTO `projet` (`idProjet`, `image`, `Titre`, `Description`, `Support`) VALUES
(20, 'http://localhost/UQO-University/site/image/pro/61bad343175df2.55304650.jpg', 'Combinatoire et Physique Math&eacute;matique', 'Adrian Tanasa est l&rsquo;auteur de l&rsquo;ouvrage &laquo; Combinatorial Physics &raquo;, publi&eacute; aux &eacute;ditions Oxford Univ. Press', 'LIVRE'),
(21, 'http://localhost/UQO-University/site/image/pro/61bad3add00856.55397690.png', 'Analyse visuelle des r&eacute;seaux multicouches', 'Le mod&egrave;le des r&eacute;seaux multicouches reconna&icirc;t que la complexit&eacute; des relations entre les entit&eacute;s de syst&egrave;mes complexes issus du monde r&eacute;el est mieux appr&eacute;hend&eacute;e sous la', 'LIVRE'),
(22, 'http://localhost/UQO-University/site/image/pro/61bad48a8f5100.52466372.jpg', 'Publication dans la revue Interstices d&rsquo;un article de Lo&iuml;c Paulev&eacute; sur la mod&eacute;lisation bool&eacute;enne', 'Pr&eacute;dire le comportement des cellules avec la mod&eacute;lisation bool&eacute;enne', 'ARTICLE / REVUE / JOURNAL'),
(23, 'http://localhost/UQO-University/site/image/pro/61bad4d25de549.21739680.jpg', 'L&eacute;o Mendiboure re&ccedil;oit le prix Abertis France', 'L&eacute;o Mendiboure, qui a soutenu sa th&egrave;se au LaBRI en 2020, vient d\'obtenir l&rsquo;un des 3 prix Abertis France qui r&eacute;compense les meilleurs travaux de recherche dans le domaine', 'ARTICLE / REVUE / JOURNAL'),
(24, 'http://localhost/UQO-University/site/image/pro/61bad523ee93c2.01767072.jpg', 'Article de Lo&iuml;c Paulev&eacute; dans Nature Communications', 'Lo&iuml;c Paulev&eacute; propose de &laquo; Concilier une mod&eacute;lisation qualitative, abstraite et qui passe &agrave; l&rsquo;&eacute;chelle pour les r&eacute;seaux biologiques &raquo;', 'ARTICLE / REVUE / JOURNAL');

-- --------------------------------------------------------

--
-- Structure de la table `subjection`
--

DROP TABLE IF EXISTS `subjection`;
CREATE TABLE IF NOT EXISTS `subjection` (
  `idSubjection` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idSubjection`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `subjection`
--

INSERT INTO `subjection` (`idSubjection`, `Nom`, `Email`, `Message`) VALUES
(53, 'Andre kokouvi Adzonyo', 'adzonyo34@gmail.com', 'fhjkj'),
(39, 'jean', 'pauladzonyo79@gmail.com', 'il y a quoi putain!!!!!!!'),
(42, 'gracia', 'pauladzonyo79@gmail.com', 'youpiee'),
(41, 'paul', 'pauladzonyo79@gmail.com', 'sa marche hm enfin!!!!!'),
(43, 'pierre', 'pauladzonyo79@gmail.com', 'hmmm\r\ncomment on fait maintenant\r\nayioo'),
(52, 'pierre', 'pauladzonyo79@gmail.com', 'hmmm\r\ncomment on fait maintenant\r\nayioo'),
(51, 'pierre', 'pauladzonyo79@gmail.com', 'hmmm\r\ncomment on fait maintenant\r\nayioo'),
(49, 'jean paul', 'pauladzonyo79@gmail.com', 'salut je suis en troisieme annee departement recherche informatique,j\'aimerais avoir des information sur le parcours');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
